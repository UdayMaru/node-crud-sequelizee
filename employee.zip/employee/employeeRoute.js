const express = require("express");
const Router = express.Router();
const employeecontroller = require("./employeecontroller.js");

Router.get("/index",employeecontroller.index);
Router.get("/show/:id",employeecontroller.show);
Router.post("/store",employeecontroller.store);
Router.put("/update/:id",employeecontroller.update);
Router.delete("/delete/:id",employeecontroller.delete);

module.exports=Router;

