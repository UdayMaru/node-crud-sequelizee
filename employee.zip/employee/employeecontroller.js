const employee = require("./employee");

exports.index = (req, res) => {
    employee.findAll()
    .then((employee) => {
        console.log("all student retrived successfully:",employee);
        res.send({ message: "employee retrieved successfully", data: employee });
    })
    .catch((error) => {
        res.send({ message: "Error retrieving employee", error });
    });
};

exports.show = (req,res)=>{
    const id=req.params.id;
    employee.findByPk(id)
    .then(employee=>{
        if(employee){
            res.send({message:"employee details",data:employee});
        }
        else{
            res.send({message:"employee not found"});
        }
    })
    .catch(err=>{
        res.send({message:"error",error:err});
    });
}

exports.store = (req, res) => {
    employee.create(req.body)
    .then((newEmployee) => {
        console.log("Employee create successfully:",newEmployee);
        res.send({ message: "Employee created successfully", data: newEmployee });
    })
    .catch((error) => {
        res.send({ message: "Error creating employee", error });
    });
};

exports.update = (req, res) => {
    employee.update(req.body, { where: { id: req.params.id } })
    .then(() => {
        console.log("Employee update successfully");
        res.send({ message: "employee updated successfully", data: req.body });
    })
    .catch((error) => {
        res.send({ message: "Error updating employee", error });
    });
};

exports.delete = (req, res) => {
    employee.destroy({ where: { id: req.params.id } })
    .then(() => {
        console.log("Employee deleted successfully");
        res.send({ message: "employee deleted successfully" });
    })
    .catch((error) => {
        res.send({ message: "Error deleting employee", error });
    });
};

