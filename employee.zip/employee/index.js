const express = require("express");
const sequelize = require("sequelize");

const employeeRoute = require("./employeeRoute");
const app = express();
const PORT = 81;
app.use(express.json());
app.use("/employee",employeeRoute);

app.listen(PORT,()=>{
    console.log("server is localhost"+PORT);
});
